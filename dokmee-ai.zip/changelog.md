## [1.0.3]

### Fixed
- Notifications: fix titles
- Tables add more padding
- Add unlock-button
- Clear code

## [1.0.2]

### Update
- Minor package updates

## [1.0.1]

### Added
- The added configuration for router module.

## [1.0.0]

### Added
- Added Angular Material Admin v1.0.0
