export const environment = {
  production: true,
  api_url: 'http://10.28.86.122/'

};
