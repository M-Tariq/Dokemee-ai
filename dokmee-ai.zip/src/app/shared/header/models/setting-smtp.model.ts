export class SmtpSetting {
    Server: string;
    Host: string;
    Port: number;
    Email: string;
    Password: string;
    // EnableSsl: boolean;
  }
  