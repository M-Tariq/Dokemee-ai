export class User {
    FirstName: string;
    LastName: string;
    Email: string;
    // ImageUrl: string;
  }
  