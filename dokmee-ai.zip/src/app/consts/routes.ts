export enum routes {
  DASHBOARD = '/dashboard',
  REPORTS = '/reports',
  COMPANY = '/company',
  ADMIN_USER = '/admin-user',
  COMPANY_CONNECTIONS = '/company/connection',
  Company_Form_Library = '/company/forml-ibrary',
  LOGIN = '/login'
}
