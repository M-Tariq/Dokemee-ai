export interface Reports {
  title: string;
  mapped_index: string;
  docs_processed: string;
}