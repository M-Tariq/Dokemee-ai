export interface ReportsHead {
  companyname: string;
  companyId: string;
  exp_date: string;
  exp_days: string;
  cabnit: string;
  doc_remaining: string;
  doc_processed: string;
  index_available: string;
  }