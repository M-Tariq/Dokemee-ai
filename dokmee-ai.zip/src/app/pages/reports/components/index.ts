export * from './reports-head-table/reports-head-table.component';
