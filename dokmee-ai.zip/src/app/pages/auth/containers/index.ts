export * from './auth-page/auth-page.component';
