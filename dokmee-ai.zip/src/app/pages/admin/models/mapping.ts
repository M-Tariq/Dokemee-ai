export interface Mapping {
    name: string;
    email: string;
  }
  