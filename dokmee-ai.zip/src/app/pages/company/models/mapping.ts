export interface Mapping {
  indexfield: string;
  indexfield1: string;
  }
  