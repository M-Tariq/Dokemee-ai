import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

import { Manager, Mapping } from '../models';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {
  public loadMaterialTableData(): Observable<Manager[]> {
    return of([
      {
        name: 'Mark Otto',
        email: 'ottoto@wxample.com',
        product: 'ON the Road',
        price: '$25 224.2',
        date: '11 May 2017',
        city: 'Otsego',
        status: 'send'
      },
      {
        name: 'Jacob Thornton',
        email: 'thornton@wxample.com',
        product: 'HP Core i7',
        price: '$1 254.2',
        date: '4 Jun 2017',
        city: 'Fivepointville',
        status: 'send'
      },
      {
        name: 'Larry the Bird',
        email: 'bird@wxample.com',
        product: 'Air Pro',
        price: '$1 570.0',
        date: '27 Aug 2017',
        city: 'Leadville North',
        status: 'pending'
      },
      {
        name: 'Joseph May',
        email: 'josephmay@wxample.com',
        product: 'Version Control',
        price: '$5 224.5',
        date: '19 Feb 2018',
        city: 'Seaforth',
        status: 'declined'
      }
    ]);
  }

  public loadMappingTableData(): Observable<Mapping[]> {
    return of([
      {
        id:1,
        indexfield: 'Mark Otto',
        indexfield1: 'ottoto@wxample.com',
      },
      {
        id:2,
        indexfield: 'Mark Otto',
        indexfield1: 'ottoto@wxample.com',
      },
      {
        id:3,
        indexfield: 'Mark Otto',
        indexfield1: 'ottoto@wxample.com',
      },
      {
        id:4,
        indexfield: 'Mark Otto',
        indexfield1: 'ottoto@wxample.com',
      },
    ]);
  }
}
