export class TokenDetail {
  Token: string;
  ExpiryDateUtc: Date;
  RefreshToken: string;
}
